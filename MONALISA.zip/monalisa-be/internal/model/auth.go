package model

type UserAuth struct {
	UserID      string
	Permissions []string
}
